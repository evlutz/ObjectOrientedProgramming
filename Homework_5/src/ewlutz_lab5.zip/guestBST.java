public class guestBST implements IBST {
    DataBST rightGuestBST = new
        IBST guestBST = new DataBST(String Data, IBST left, IBST right);

}