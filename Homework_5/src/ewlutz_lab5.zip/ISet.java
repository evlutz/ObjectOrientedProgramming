public interface ISet {

    public void addElt(ISet newGuestName);
    public boolean hasElt(ISet guest);
    public int size();



}
