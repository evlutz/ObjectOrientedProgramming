//ewlutz
//Evan Lutz

//brmarsh
//Ben Marsh
public interface IChallenge {
	//returns the average number of books or words the Literarian achieved 
	public double averagePerDay();
	
	//the average number of books or words the Literarian needs to increase
	//by per day to meet the goal of the challenge.
	public double differenceFromGoal();
}
