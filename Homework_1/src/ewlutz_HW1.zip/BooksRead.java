//ewlutz
//Evan Lutz

//brmarsh
//Ben Marsh
public class BooksRead {
	double booksRead;
	
	public BooksRead (double booksRead) {
		this.booksRead = booksRead;
	}
}
